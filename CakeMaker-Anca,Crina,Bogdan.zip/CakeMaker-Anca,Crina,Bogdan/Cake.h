#pragma once
#include <iostream>
#include <string>

using namespace std;

class Cake
{
	string name;
public:
	Cake(string name);
	Cake();
	string getName();
};
